﻿
public abstract class Shape
{
    public abstract double Perimeter();
    public abstract double Area();
    
}
interface IEllipse
{
    bool isEllipse();
}
public class Rectangle:Shape, IEllipse
{
    public double Hight { get; set; }
    public double Width { get; set; }
    public Rectangle(double width, double hight)
    {
        this.Hight = hight;
        this.Width = width;
    }

    public bool isEllipse()
    {
        return true;
    }
    public override double Area()
    {
        return Hight * Width;
    }

    public override double Perimeter()
    {
        return (Hight + Width) * 2;
    }

}
public class Circle : Shape, IEllipse
{
    public double Radius { get; set; }
    public Circle(double radius)
    {
        this.Radius = radius;
    }
    public bool isEllipse()
    {
        return true;
    }

    public override double Area()
    {
        return Math.PI * Radius * Radius;
    }

    public override double Perimeter()
    {
        return 2 * Math.PI * Radius;
    }
}
public class Square : Rectangle
{
    public Square(double side) : base(side, side)
    {
    }
    public double Area(double side)
    {
        return side * side;
    }
}
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Изберете фигура - 1:Правоъгълник, 2:Квадрат, 3:Кръг");
        int number = int.Parse(Console.ReadLine());
        Shape shape;
        switch(number)
        {
            case 1:
                Console.WriteLine("височина");
                double hight = double.Parse(Console.ReadLine());
                Console.WriteLine("широчина");
                double width = double.Parse(Console.ReadLine());
                shape = new Rectangle(hight,width);
                break;
            case 2:
                Console.WriteLine("страна");
                double size = double.Parse(Console.ReadLine());
                shape = new Square(size);
                break;
            case 3:
                Console.WriteLine("радиус");
                double radius = double.Parse(Console.ReadLine());
                shape = new Circle(radius);
                break;
            default:
                Console.WriteLine("грешка");
                return;
        }
        Console.WriteLine(shape.Area());
        Console.WriteLine(shape.Perimeter());
    }
}